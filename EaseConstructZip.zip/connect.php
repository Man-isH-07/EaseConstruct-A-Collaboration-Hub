<?php
 
$conn = mysqli_connect('localhost', 'root' ,'', 'easeconstruct');

if(!$conn)
{
    echo 'Error';
}